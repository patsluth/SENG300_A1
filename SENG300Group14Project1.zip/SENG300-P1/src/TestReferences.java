import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class TestReferences {
	
	private static String BASEDIR = "D:\\Aaron\\Desktop\\Eclipse\\SENG300-P1\\src\\TestFiles";

	@Before
	public void setUp() {
		Main.declarationCount = 0; // reset static
		Main.referenceCount = 0; // reset static
	}

	// 1 simple reference
	@Test
	public void testR1() {
		String[] args = new String[2];
		args[0] = BASEDIR;
		args[1] = "TestFiles.R1"; 
		Main.main(args); 
		assertEquals(Main.referenceCount, 1); 
	}

	// 1 simple reference + constructor reference
	@Test
	public void testR2() {
		String[] args = new String[2];
		args[0] = BASEDIR;
		args[1] = "TestFiles.R2"; 
		Main.main(args); 
		assertEquals(Main.referenceCount, 2); 
	}
	
	// 2 inner class references in different scope
	@Test
	public void testR3() {
		String[] args = new String[2];
		args[0] = BASEDIR;
		args[1] = "TestFiles.R3.R3Inner"; 
		Main.main(args); 
		assertEquals(Main.referenceCount, 2); 
	}
	
	// class without explicit package
	@Test
	public void testR4() {
		String[] args = new String[2];
		args[0] = BASEDIR;
		args[1] = "R4"; 
		Main.main(args); 
		assertEquals(Main.referenceCount, 1); 
	}	
	
	// testing import recognition
	@Test
	public void testR5() {
		String[] args = new String[2];
		args[0] = BASEDIR;
		args[1] = "java.util.Scanner"; 
		Main.main(args); 
		assertEquals(Main.referenceCount, 2); 
	}		

}
