package TestFiles; 

public class T1 { // TestFiles.T1
	class T1c {} // TestFiles.T1c
	interface T1i {} // TestFiles.T1i
	enum T1e {} // TestFiles.T1e
	@interface T1a {} // TestFiles.T1a
}