package TestFiles;

public class R3 {
	
	R3Inner r1; 
	
	private class R3Inner{
		
		R3Inner r2; 
		
	}
}
