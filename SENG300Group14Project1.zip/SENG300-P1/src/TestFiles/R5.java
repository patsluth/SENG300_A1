package TestFiles;

import java.util.Scanner;

public class R5 {
	
	Scanner s1; 
	java.util.Scanner s2;
	
}
