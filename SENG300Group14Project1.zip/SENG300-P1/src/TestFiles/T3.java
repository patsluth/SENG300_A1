package TestFiles;

public enum T3 {;
	class T3c {}
	interface T3i {}
	enum T3e {}
	@interface T3a {}
}