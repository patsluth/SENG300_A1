package TestFiles;
 
public @interface T4 {
	class T4c {}
	interface T4i {}
	enum T4e {}
	@interface T4a {}
}
