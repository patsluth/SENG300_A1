package TestFiles;

public interface T2 {
	class T2c {}
	interface T2i {}
	enum T2e {}
	@interface T2a {}
}