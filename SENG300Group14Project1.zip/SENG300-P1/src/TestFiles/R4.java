

public class R4 {
	R4 r; 
}
