package TestFiles;

public class R1 {
	R1 r; 
}
