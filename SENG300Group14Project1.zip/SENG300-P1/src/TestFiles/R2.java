package TestFiles;

public class R2 {
	R2 r = new R2(); 
}
