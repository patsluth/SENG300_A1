import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class TestDeclarations {
	
	private static String BASEDIR = "D:\\Aaron\\Desktop\\Eclipse\\SENG300-P1\\src\\TestFiles";
	
	@Before
	public void setUp() {
		Main.declarationCount = 0; // reset static
		Main.referenceCount = 0; // reset static
	}

	// inner class of class
	@Test
	public void testParse1() {
		String[] args = new String[2];
		args[0] = BASEDIR;
		args[1] = "TestFiles.T1.T1c"; 
		Main.main(args); 
		assertEquals(Main.declarationCount, 1); 
	}
	
	// inner interface of class
	@Test
	public void testParse2() {
		String[] args = new String[2];
		args[0] = BASEDIR;
		args[1] = "TestFiles.T1.T1i"; 
		Main.main(args); 
		assertEquals(Main.declarationCount, 1); 
	}
	
	// inner enum of class
	@Test
	public void testParse3() {
		String[] args = new String[2];
		args[0] = BASEDIR;
		args[1] = "TestFiles.T1.T1e"; 
		Main.main(args); 
		assertEquals(Main.declarationCount, 1); 
	}
	
	// inner annotation of class
	@Test
	public void testParse4() {
		String[] args = new String[2];
		args[0] = BASEDIR;
		args[1] = "TestFiles.T1.T1a"; 
		Main.main(args); 
		assertEquals(Main.declarationCount, 1); 
	}
	
	// inner class of interface
	@Test
	public void testParse5() {
		String[] args = new String[2];
		args[0] = BASEDIR;
		args[1] = "TestFiles.T2.T2c"; 
		Main.main(args); 
		assertEquals(Main.declarationCount, 1); 
	}
	
	// inner interface of interface
	@Test
	public void testParse6() {
		String[] args = new String[2];
		args[0] = BASEDIR;
		args[1] = "TestFiles.T2.T2i"; 
		Main.main(args); 
		assertEquals(Main.declarationCount, 1); 
	}
	
	// inner enum of interface
	@Test
	public void testParse7() {
		String[] args = new String[2];
		args[0] = BASEDIR;
		args[1] = "TestFiles.T2.T2e"; 
		Main.main(args); 
		assertEquals(Main.declarationCount, 1); 
	}
	
	// inner annotation of interface
	@Test
	public void testParse8() {
		String[] args = new String[2];
		args[0] = BASEDIR;
		args[1] = "TestFiles.T2.T2a"; 
		Main.main(args); 
		assertEquals(Main.declarationCount, 1); 
	}
	
	// inner class of enum
	@Test
	public void testParse9() {
		String[] args = new String[2];
		args[0] = BASEDIR;
		args[1] = "TestFiles.T3.T3c"; 
		Main.main(args); 
		assertEquals(Main.declarationCount, 1); 
	}
	
	// inner interface of enum
	@Test
	public void testParse10() {
		String[] args = new String[2];
		args[0] = BASEDIR;
		args[1] = "TestFiles.T3.T3i"; 
		Main.main(args); 
		assertEquals(Main.declarationCount, 1); 
	}
	
	// inner enum of enum
	@Test
	public void testParse11() {
		String[] args = new String[2];
		args[0] = BASEDIR;
		args[1] = "TestFiles.T3.T3e"; 
		Main.main(args); 
		assertEquals(Main.declarationCount, 1); 
	}
	
	// inner annotation of enum
	@Test
	public void testParse12() {
		String[] args = new String[2];
		args[0] = BASEDIR;
		args[1] = "TestFiles.T3.T3a"; 
		Main.main(args); 
		assertEquals(Main.declarationCount, 1); 
	}
	
	// inner class of annotation
	@Test
	public void testParse13() {
		String[] args = new String[2];
		args[0] = BASEDIR;
		args[1] = "TestFiles.T4.T4c"; 
		Main.main(args); 
		assertEquals(Main.declarationCount, 1); 
	}
	
	// inner interface of annotation
	@Test
	public void testParse14() {
		String[] args = new String[2];
		args[0] = BASEDIR;
		args[1] = "TestFiles.T4.T4i"; 
		Main.main(args); 
		assertEquals(Main.declarationCount, 1); 
	}
	
	// inner enum of annotation
	@Test
	public void testParse15() {
		String[] args = new String[2];
		args[0] = BASEDIR;
		args[1] = "TestFiles.T4.T4e"; 
		Main.main(args); 
		assertEquals(Main.declarationCount, 1); 
	}
	
	// inner annotation of annotation
	@Test
	public void testParse16() {
		String[] args = new String[2];
		args[0] = BASEDIR;
		args[1] = "TestFiles.T4.T4a"; 
		Main.main(args); 
		assertEquals(Main.declarationCount, 1); 
	}

}
